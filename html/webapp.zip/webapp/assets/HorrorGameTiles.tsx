<?xml version="1.0" encoding="UTF-8"?>
<tileset name="HorrorGameTiles" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="../../input_assets/game/HorrorGameTiles.png" width="256" height="256"/>
</tileset>
